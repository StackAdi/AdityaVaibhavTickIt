package com.capgemini.movie.controller;
import java.util.*;

import com.capgemini.movie.model.Movie;
import com.capgemini.movie.model.Theatre;

public class AdminServices {
	
	Scanner sc = new Scanner(System.in) ;
	
	public Theatre addTheatre() 
	{
		Theatre the = new Theatre();
		
		System.out.println("-----Enter Theatre ID------");
		the.setTheaterId(sc.nextInt());
		sc.nextLine();
		
		System.out.println("-------Enter Theatre Name------");
		the.setTheaterName(sc.nextLine());
		
		System.out.println("-------Enter Theatre City------");
		the.setTheaterCity(sc.nextLine());
		
	
		System.out.println("-------Enter Manager Name------");
		the.setManagerName(sc.nextLine());
		
		System.out.println("-------Enter Manager Contact------");
		the.setManagerContact(sc.nextLine());
		
		System.out.println("How many movies you want to add:");
		int movieCount = sc.nextInt();
		
		for(int i=0;i<movieCount;i++)
		{
			Movie m = addMovie();
			HashMap<Integer, Movie> hsmov = the.getHsmovie();
			hsmov.put(m.getMovieId(), m);
			System.out.println(hsmov);
			the.setHsmovie(hsmov);
		}
		
		   return the;
	 }
	
	
	public Movie addMovie() 
	{
		
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in) ;
		System.out.println("Enter Movie Details :  ");
	
		System.out.println("------Enter Movie ID ------");
		int movieId = sc.nextInt();
		sc.nextLine();
		
		System.out.println("------Enter Movie Name ------");
		String movieName = sc.nextLine() ;
	
		System.out.println("------Enter Movie Director ------");
		String movieDirector = sc.nextLine() ;	
	
		System.out.println("-------Enter Movie Length(in mins)------");
		int movieLength = sc.nextInt() ;
		sc.nextLine();
		
		System.out.println("------Enter Movie Release Date------");
		String movieReleaseDate = sc.nextLine();
		
		Movie m = new Movie(movieId, movieName, movieDirector, movieLength, movieReleaseDate);
		return m;
		
	}
	
	/*
	 * public static void viewMovies() {
	 * 
	 * HashMap<Integer,Theatre> hs = TheatreService.getTheatrehs(); for(Theatre t :
	 * hs.values()) { String[] str= t.getMovie() ; for(int i = 0 ; i<1 ; i++) {
	 * System.out.print("> "+str[i]); } System.out.println();
	 * //BookingServices.bookMovie();
	 * 
	 * //System.out.println("---------------------------------------"); } }
	 */
	   
	/*
	 * public void updateMovie(int movieId) { HashMap<Integer,Theatre> hs =
	 * TheatreService.getTheatrehs(); if(hs.containsKey(movieId)) { Theatre t =
	 * hs.get(movieId); System.out.println("Enter Movie Details :  "); String str[]
	 * = new String[4] ;
	 * 
	 * System.out.println("------Enter Movie Name ------"); str[0]=sc.nextLine() ;
	 * 
	 * System.out.println("------Enter Movie Director ------"); str[1]=sc.nextLine()
	 * ;
	 * 
	 * System.out.println("-------Enter Movie Length(in mins)------");
	 * str[2]=sc.nextLine() ;
	 * 
	 * 
	 * System.out.println("------Enter Movie Release Date------");
	 * str[3]=sc.nextLine() ; m.setMovies(str);
	 * 
	 * moviehs.put(movieId, t);
	 * 
	 * MovieServices.setMovies(moviehs);
	 * 
	 * } }
	 */
	/*
	 * public void updateMovies(int movieID) { moviehs.put(movieId, t);
	 * 
	 * MovieServices.setMovies(moviehs); }
	 */
	   
	   public void deleteMovie(int tid) 
	   {
		   HashMap<Integer,Theatre> hs = TheatreService.getTheatrehs();
		   if(hs.containsKey(tid)) {
			   Theatre t = hs.get(tid);
			   hs.remove(tid,t) ;   
		  }
	   }
	
}
