package com.capgemini.movie.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectInputStream.GetField;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.movie.model.Movie;
import com.capgemini.movie.model.Theatre;

public class BookingServices {

	public static void bookMovie() throws IOException, ClassNotFoundException 
	{
		// TODO Auto-generated method stub
		/* Scanner sc = new Scanner(System.in); */
		File f = new File("C:\\CapGemini\\Project\\TickIt\\src\\main\\resources\\FileMovie.txt") ;
		FileInputStream fin = new FileInputStream(f);
		ObjectInputStream in = new ObjectInputStream(fin);
		HashMap<Integer, Movie> moviehs =  (HashMap<Integer,Movie>)in.readObject();
		
		for(Map.Entry m:moviehs.entrySet()) {
			System.out.println(m.getValue());
			
		}
		in.close();
		fin.close();
	}
}

